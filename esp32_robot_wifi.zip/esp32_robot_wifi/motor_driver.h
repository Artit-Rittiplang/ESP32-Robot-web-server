#define LEFT_MOTOR_ENABLE    32 // ENA
#define LEFT_MOTOR_FORWARD   33 // IN1
#define LEFT_MOTOR_BACKWARD  25 // IN2

#define RIGHT_MOTOR_FORWARD  26 // IN3
#define RIGHT_MOTOR_BACKWARD 27 // IN4
#define RIGHT_MOTOR_ENABLE   23 // ENB

void initMotorController();
void setMotorSpeed(int i, int spd);
void setMotorSpeeds(int leftSpeed, int rightSpeed);


