#ifndef WIFI_SERVER_H
#define WIFI_SERVER_H

// Initialize Wi-Fi and Web Server
void initWiFi();

// Handle incoming web client requests (call this in loop)
void handleWiFi();

#endif