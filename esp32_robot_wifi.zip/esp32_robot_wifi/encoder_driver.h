#define LEFT_ENC_PIN_A   19
#define LEFT_ENC_PIN_B   18

#define RIGHT_ENC_PIN_A  16
#define RIGHT_ENC_PIN_B  17

void initEncoders();
long readEncoder(int i);
void resetEncoder(int i);
void resetEncoders();

