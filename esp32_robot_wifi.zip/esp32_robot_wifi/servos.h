#ifndef SERVOS_H
#define SERVOS_H

#include <Arduino.h>

#define SERVO_COUNT 3

extern volatile int servoTarget[SERVO_COUNT];

void initServos();
void Servo_do();

void setServoTarget(int index, int degree);

#endif
